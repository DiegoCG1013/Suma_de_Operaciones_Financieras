public class DialogoMac implements Dialogo{

    public int conversar(){
        System.out.println("Hola, soy un dialogo de Mac");
        return 0;
    }

}
