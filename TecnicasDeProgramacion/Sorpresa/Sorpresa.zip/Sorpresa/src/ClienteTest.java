class ClienteTest {

    @org.junit.jupiter.api.Test
    void main() {
        //No hay metodos que probar
    }
}