public interface Dialogo {
    public int conversar();
}
